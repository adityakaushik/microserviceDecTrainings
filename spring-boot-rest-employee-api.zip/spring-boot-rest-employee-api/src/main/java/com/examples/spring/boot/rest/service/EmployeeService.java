package com.examples.spring.boot.rest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examples.spring.boot.rest.model.Employee;
import com.examples.spring.boot.rest.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;

	public List<Employee> fetchAllEmployees() {
		return employeeRepository.findAll();
	}

	public Integer addEmployee(Employee employee) {

		employeeRepository.save(employee);
		return employee.getId();
	}

	public void updateEmployee(Employee employee) {
		employeeRepository.save(employee);
	}

	public Employee get(Integer empId) {
		Optional<Employee> emp = employeeRepository.findById(empId);
		return emp.isPresent() ? emp.get() : null;
	}

	public void deleteEmployee(Integer empId) {

		employeeRepository.deleteById(empId);
	}

	public void clear() {
		employeeRepository.deleteAll();
	}

}
